import Error404 from '/components/404/FourOhFour'

export default function FourOhFour(prop){
    return <>
        <Error404 />
    </>
}